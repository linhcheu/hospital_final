<?php
include("connection.php");
$vaccinaiton_card="";
if(isset($_POST["button_save"])){
    $vaccination_card = $_POST["vaccination_card"];
    $vaccinaiton_name = $_POST["vaccinaiton_name"];
    $vaccination_date = date('Y-m-d h:i:s');
    $qry = mysqli_query($con, "insert into vaccination_information values(NULL,'".$vaccinaiton_card."','".$vaccinaiton_name."', '".$vaccination_date."')");
    if($qry){
        echo "Inserted";
    }
    else{
        echo "Cannot Insert";
    }
}
else {
    $vaccinaiton_card = $_GET["id"];
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Vaccination Information</title>
</head>
<body>
    <h1>Insert vaccination Information</h1>
    <form action='<?php echo $_SERVER["PHP_SELF"]; ?>' method="post";>
    <table>
        <tr><td>Vaccination Card</td><td><input readonly type="text" name="vaccination_card" value='<?php echo $_GET["id"] ?>'/></td></tr>
        <tr><td>Vaccination Name</td><td><input type="text" name="vaccination_name" /></td></tr>
        <tr><td></td><td><input type="submit" name="button_save" value="Save"/></td></tr>

    </table>

   </form>
</body>
</html>