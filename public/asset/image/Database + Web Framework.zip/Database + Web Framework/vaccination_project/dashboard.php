<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vaccination Dashboard</title>
</head>
<body>
    <h1>Vaccination Dashboard</h1>
    <table border="1">
        <tr>
            <th>Staffs</th>
           
        </tr>
        <tr>
           <a href="insert_staffs.php">Insert Staffs</a> <br />
           <a href="select_all_staffs.php">All Staffs</a> <br />
        </tr>
     

    </table>
    
</body>
</html>