<?php
$vaccination_card="";
$phone_number="";
$first_name= "";
$last_name="";
$id_card= "";
include ('connection.php');


if(isset($_POST["button_update"])){
    $vaccination_card=$_POST["vaccination_card"];
    $phone_number=$_POST["phone_number"];
    $first_name=$_POST["first_name"];
    $last_name=$_POST["last_name"];
    $id_card= $_POST["id_card"];
    $qry=mysqli_query($con, "update staffs set phone_number='".$phone_number."',first_name='".$first_name."',last_name='".$last_name."',id_card='".$id_card."' where vaccination_card='".$vaccination_card."'");
    if($qry){
        echo "Updated Successfully";
    }
    else{
        echo "Updated Failed";
    }
}
else{
    if($con){
    $qry = mysqli_query($con, "select * from staffs where vaccination_card='".$_GET["id"]."'");
    while($row=mysqli_fetch_array($qry,MYSQLI_ASSOC)){
        $vaccination_card=$row["vaccination_card"];
        $phone_number=$row["phone_number"];
        $first_name= $row["first_name"];
        $last_name=$row["last_name"];
        $id_card=$row["id_card"];
    }
}
else{
    echo "Connect is failied";
}
}


if(isset($_POST["button_update"])){
    echo "Updateed";

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update a Staff</title>
</head>
<body>
    <h1>Update a Staff</h1>
    <form action='<?php echo $_SERVER["PHP_SELF"];?>' method="post" >
        <table>
            <tr><td>Vaccination Card</td><td><input type="text" name="vaccination_card" value="<?php echo $vaccination_card?>" /></td></tr>
            <tr><td>Phone Number</td><td><input type="text" name="phone_number" value="<?php echo $phone_number?>" /></td></tr>
            <tr><td>First Name</td><td><input type="text" name="first_name" value="<?php echo $first_name?>"/></td></tr>
            <tr><td>Last Name</td><td><input type="text" name="last_name" value="<?php echo $last_name?>" /></td></tr>
            <tr><td>ID Card</td><td><input type="text" name="id_card" value="<?php echo $id_card?>"/></td></tr>
            <tr><td></td><td><input type="submit" name="button_update" value="Update" /></td></tr>

        </table>
    </form>


</body>
</html>