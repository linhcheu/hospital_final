<?php
$id="";
$vaccination_card="";
$vaccination_name="";
$vaccination_date= "";
include ('connection.php');


if(isset($_POST["button_update"])){
    $id = $_POST["id"];
    $vaccinaiton_card = $_POST["vaccination_card"];
    $vaccination_name = $_POST["vaccination_name"];
    $qry =mysqli_query($con, "update vaccination_information set
        vaccination_name = '".$vaccination_name."',
        vaccination_date = '".date('Y-m-d h:i:s')."'
        where id = '".$id."'
    ");
    if($qry){
        echo "Update Succeed";
    }
    else{
        echo "Update Failed";
    }
    
}
else{
    if($con){
   $qry = mysqli_query($con, "select * from vaccination_information where id='".$_GET["id"]."'");
   while($row=mysqli_fetch_array($qry,MYSQLI_ASSOC)){
        $id=$row["id"];
        $vaccination_card=$row["vaccination_card"];
        $vaccination_name= $row["vaccination_name"];
        $vaccination_date=$row["vaccination_date"];
       
}
}
else{
   echo "Connect is failied";
}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Vaccination Information</title>
</head>
<body>
    <h1>Update a Staff</h1>
    <form action='<?php echo $_SERVER["PHP_SELF"];?>' method="post" >
        <table>
            <tr><td>ID</td><td><input type="text" name="id" value='<?php echo $id;?>' /></td></tr>
            <tr><td>Vaccination Card</td><td><input type="text" name="vaccination_card" value='<?php echo $vaccination_card?>' /></td></tr>
            <tr><td>Vaccination Name</td><td><input type ="text" name="vaccination_name" value='<?php echo $vaccination_name?>' /></td></tr>
            <tr><td>Vaccination Date</td><td><input type ="text" name="vaccination_date" value='<?php echo $vaccination_date?>' /></td></tr>
            <tr><td></td><td><input type="submit" value="Update Info" name="button_update" /></td></tr>
        
        </table>
    </form>


</body>
</html>