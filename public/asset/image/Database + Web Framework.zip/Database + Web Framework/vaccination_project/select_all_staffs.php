<?php
include("connection.php");
if(isset($_GET["id"])){
    $qry = mysqli_query($con, "delete from staffs where vaccination_card='".$_GET["id"]."'");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List All Staffs</title>
</head>
<body>
    <h1>List All Staffs</h1>
    <table border = "1">
    <tr>
        <th>Vaccination Card</th>
        <th>Phone Number</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>ID Card</th>
        <th>Action</th>
    </tr>
        
<?php

if($con){
    $qry = mysqli_query($con,"select * from staffs order by vaccination_card desc");
    if($qry){
        while($row=mysqli_fetch_array($qry,MYSQLI_ASSOC)){
            echo "<tr>";
                echo "<td>".$row["vaccination_card"]."</td>";
                echo "<td>".$row["phone_number"]."</td>";
                echo "<td>".$row["first_name"]."</td>";
                echo "<td>".$row["last_name"]."</td>";
                echo "<td>".$row["id_card"]."</td>";
                echo "<td><a href = 'update_staff.php?id=".$row["vaccination_card"]."'> Edit </a> | <a href = 'select_all_staffs.php?id=".$row["vaccination_card"]."'> Delete </a> </td>";
                echo "<td><a href='add_info.php?id=".$row["vaccination_card"]."'>Add</a>";
                echo "<a href='selete_all_info.php?id='>List Vaccines</a>";
                echo "<a href='select_all_info.php?id=".$row["vaccination_card"]."'>List Vaccines</a></td>";
                echo "</tr>";
        }
    }
    else{
        echo "Cannot Query to the Database";
    }
}
else{
    echo "Connection Failed";
}
?>

    </table>


</body>
</html>