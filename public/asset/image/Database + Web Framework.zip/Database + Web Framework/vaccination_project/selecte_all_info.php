<?php

include("connection.php");
if(isset($_GET["delete_id"])){
    $qry = mysqli_query($con, "delete from vaccination_information where id='".$_GET["delete_id"]."'");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List All Infos</title>
</head>
<body>
    <h1>List All Infos</h1>
    <table border = "1">
    <tr>
        <th>Vaccination Card</th>
        <th>Vaccination Name</th>
        <th>Vaccination Date</th>
        <th>Actions</th>
    </tr>
        
<?php

if($con){
    $qry = mysqli_query($con,"select * from vaccination_information where vaccination_card='".$GET["id"]."'order by vaccination_card desc");
    if($qry){
        while($row=mysqli_fetch_array($qry,MYSQLI_ASSOC)){
            echo "<tr>";
                echo "<td>".$row["vaccination_card"]."</td>";
                echo "<td>".$row["vaccination_name"]."</td>";
                echo "<td>".$row["vaccination_date"]."</td>";
                echo "<td><a href='edit_info.php?id=".$row["id"]."'>Edit</a>";
                echo " |  <a href='select_all_info.php? id=".$_GET["id"]."&delte_id=".$row["id"]."'>Delete</td>";       
                echo "</tr>";
        }
    }
    else{
        echo "Cannot Query to the Database";
    }
}
else{
    echo "Connection Failed";
}
?>

    </table>


</body>
</html>