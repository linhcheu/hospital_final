<?php

    $con = mysqli_connect("localhost","vaccination","root","vaccination");

    if($con){
        $qry = mysqli_query($con,"insert into staffs values('".
        $vaccination_card."','".$phone_number."','".$first_name."','".$last_name."','".$id_card."')");
        if($qry){
            echo "Inserted success";
        }
        else{
            echo "Inserted failed";
        }
    }
    else{
        echo "Failed Connection";
    }

    
?>
