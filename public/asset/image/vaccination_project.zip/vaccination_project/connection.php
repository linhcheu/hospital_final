<?php

    $con = mysqli_connect("localhost","vaccination","root","vaccination");

    
?>
