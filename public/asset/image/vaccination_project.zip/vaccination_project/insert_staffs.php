<?php

include ("connection.php");

if(isset($_POST["button_save"])){
    $vaccination_card = $_POST["vaccination_card"];
    $phone_number = $_POST["phone_number"];
    $first_name = $_POST["first_name"];
    $last_name = $_POST["last_name"];
    $id_card = $_POST["id_card"];
    
    $con = mysqli_connect("localhost","vaccination","root","vaccination");

    if($con){
        $qry = mysqli_query($con,"insert into staffs values('".
        $vaccination_card."','".$phone_number."','".$first_name."','".$last_name."','".$id_card."')");
        if($qry){
            echo "Inserted success";
        }
        else{
            echo "Inserted failed";
        }
    }
    else{
        echo "Failed Connection";
    }

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert a Staff</title>
</head>
<body>
    <h1>Insert a Staff</h1>
    <form action='<?php echo $_SERVER["PHP_SELF"];?>' method="post" >
        <table>
            <tr><td>Vaccination Card</td><td><input type="text" name="vaccination_card" /></td></tr>
            <tr><td>Phone Number</td><td><input type="text" name="phone_number" /></td></tr>
            <tr><td>First Name</td><td><input type="text" name="first_name" /></td></tr>
            <tr><td>Last Name</td><td><input type="text" name="last_name" /></td></tr>
            <tr><td>ID Card</td><td><input type="text" name="id_card" /></td></tr>
            <tr><td></td><td><input type="submit" name="button_save" value="Save" /></td></tr>

        </table>
    </form>


</body>
</html>